# جزوهٔ آموزشی جامع عربی دوازدهم انسانی — دکتر مریم هاشمیان

قالب کامل LaTeX (XeLaTeX + xepersian) برای جزوهٔ پنج‌درسیِ «عربی، زبان قرآن ۳ — علوم انسانی».

## ساختار پروژه

```
main.tex                        فایل اصلی (جلد، شناسنامه، فهرست، فراخوانی همهٔ بخش‌ها)
.latexmkrc                      تنظیم خودکار کامپایل با latexmk
style/hashemian.sty             استایل: رنگ‌ها، سربرگ، عنوان‌ها، کادرها، جدول واژگان، تست و پاسخنامه
frontmatter/intro.tex           سخن آغازین + راهنمای استفاده + ساختار سؤال‌های کنکور
lessons/lesson01/lesson01.tex   درس اول   ✅ کامل (الداء و الدواء — حروف مشبهه و لا نفی جنس)
lessons/lesson02/lesson02.tex   درس دوم   ✅ کامل (الوجه النافع و الوجه المضر — الحال)
lessons/lesson03/lesson03.tex   درس سوم   🟡 قالب آماده (متن ارسال نشده)
lessons/lesson04/lesson04.tex   درس چهارم 🟡 قالب آماده
lessons/lesson05/lesson05.tex   درس پنجم  🟡 قالب آماده
backmatter/glossary.tex         پیوست ۱: واژه‌نامهٔ الفبایی جامع
backmatter/grammar.tex          پیوست ۲: مرور سریع + درسنامهٔ جامع قواعد (+ پیش‌نیازهای دهم و یازدهم)
backmatter/tests.tex            پیوست ۳: ۲۴ تست تکمیلی درس‌به‌درس
backmatter/exams.tex            پیوست ۴: دو آزمون جامع ۱۵ سؤالی مشابه کنکور
backmatter/answers.tex          پیوست ۵: کلید سریع + پاسخ تشریحی ۵۴ تست
```

## پیش‌نیازها

* **TeX Live 2022 یا جدیدتر** (توزیع کامل توصیه می‌شود) یا MiKTeX به‌روز
* بسته‌ها: `xepersian`, `bidi`, `tcolorbox`, `titlesec`, `subfiles`, `enumitem`, `longtable`, `pifont`, `needspace`, `etoolbox`, `hyperref`
* قلم‌ها (هر دو در TeX Live کامل موجودند):
  * **Vazirmatn** — متن فارسی و ارقام
  * **Amiri** — متون عربی و آیات

  اگر قلم‌ها نصب نیستند، از <https://github.com/rastikerdar/vazirmatn> و <https://www.amirifont.org> دریافت و نصب کنید، یا در `main.tex` خطوط `\settextfont` و `\defpersianfont\arabfont` را به قلم‌های موجود (مثلاً `XB Niloofar`، `IRLotus`، `Scheherazade New`) تغییر دهید.

## کامپایل

### روش ۱: latexmk (پیشنهادی)
```bash
latexmk
```
فایل `.latexmkrc` موتور را روی XeLaTeX تنظیم کرده و تعداد اجراها را خودش مدیریت می‌کند. خروجی: `main.pdf`

### روش ۲: دستی
```bash
xelatex main.tex
xelatex main.tex     # بار دوم برای فهرست مطالب و ارجاع‌ها
```

### کامپایل یک درس به‌تنهایی
هر فایل درس با بستهٔ `subfiles` مستقل است:
```bash
cd lessons/lesson01
xelatex lesson01.tex
```

## تکمیل درس‌های ۳ تا ۵

۱. فایل `lessons/lesson0X/lesson0X.tex` را باز کنید.
۲. کادرهای زرد «در انتظار تکمیل» و متن‌های نمونه را با محتوای کتاب جایگزین کنید (الگوی کامل در درس ۱ و ۲).
۳. واژگان درس را به `backmatter/glossary.tex`، خلاصهٔ قواعد را به `backmatter/grammar.tex`، تست‌ها را به `backmatter/tests.tex` و پاسخ‌ها را به `backmatter/answers.tex` بیفزایید.

## ماکروهای پرکاربرد

| ماکرو | کاربرد |
|---|---|
| `\lessonopening{عنوان}{حدیث}{منبع}{ترجمه}` | صفحهٔ آغاز درس |
| `\lessonmap{متن}{واژگان}{قواعد}{تمرین}` | نقشهٔ درس |
| `\begin{lessontext} … \end{lessontext}` | کادر متن درس |
| `\poemtitle{}` / `\bayt{مصراع ۱}{مصراع ۲}` / `\tarjome{}` | شعر و ترجمهٔ بیت |
| `\arpar{}` / `\fapar{}` | بند عربی / ترجمهٔ فارسی (نثر) |
| `\begin{vocablist}[عنوان] \word{واژه}{معنا}{توضیح} \end{vocablist}` | جدول واژگان |
| `grammarbox{عنوان}`, `notebox`, `konkurbox`, `warnbox`, `examplebox` | کادرهای قواعد و نکات |
| `selftest{(۱): …}`, `exercisebox{…}`, `answerbox{…}`, `summarybox` | خودآزمایی، تمرین، پاسخ، خلاصه |
| `\quran[سوره: آیه]{متن}` / `\hadith{متن}{منبع}` | آیه و حدیث |
| `\ar{}` / `\key{}` / `\ul{}` / `\correct{}` | عربی درون‌خطی / کلیدواژهٔ قرمز / زیرخط / پاسخ سبز |
| `\blank[طول]` / `\answerlines[n]` / `\chk` / `\chkY` / `\chkN` | جای خالی، خط پاسخ، مربع، ✓، ✗ |
| `\test{صورت}{۱}{۲}{۳}{۴}` / `\testl{…}` | تست با گزینه‌های کوتاه (دو ستونه) / بلند |
| `\testgroup{عنوان}` / `\resettests` | عنوان دستهٔ تست / صفر کردن شمارنده |
| `\pasokh{شماره}{گزینه}{توضیح}` | پاسخ تشریحی |
