# تنظیمات latexmk برای کامپایل خودکار با XeLaTeX
# اجرا:  latexmk            (ساخت main.pdf)
#        latexmk -c         (پاک کردن فایل‌های کمکی)
$pdf_mode = 5;                      # 5 = xelatex
$xelatex = 'xelatex -interaction=nonstopmode -synctex=1 -file-line-error %O %S';
$postscript_mode = $dvi_mode = 0;
@default_files = ('main.tex');
$clean_ext = 'synctex.gz run.xml bbl bcf fdb_latexmk fls xdv';
$max_repeat = 5;
